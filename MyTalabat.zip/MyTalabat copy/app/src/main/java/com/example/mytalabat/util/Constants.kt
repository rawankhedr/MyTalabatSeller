package com.example.mytalabat.util

object Constants {
    const val USERS_REF = "users"
    const val PROFILES_REF = "profiles"
    const val PREFS_NAME = "mytalabat_prefs"
    const val KEY_USER_ID = "user_id"
}