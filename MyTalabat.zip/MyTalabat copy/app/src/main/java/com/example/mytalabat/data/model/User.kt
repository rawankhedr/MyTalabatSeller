package com.example.mytalabat.data.model

data class User(
    val uid: String = "",
    val email: String = ""
)